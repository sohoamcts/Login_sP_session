﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.Security;
public partial class Login : System.Web.UI.Page
{
    string conn = ConfigurationManager.ConnectionStrings["cts"].ConnectionString;
 
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(conn);
        try
        {
          
            con.Open();



            SqlCommand cmd = new SqlCommand("Emplogin", con);

            cmd.CommandType = CommandType.StoredProcedure;

            SqlParameter p1 = new SqlParameter("@Usename", TextBox1.Text);

            SqlParameter p2 = new SqlParameter("@word", TextBox2.Text);

            cmd.Parameters.Add(p1);

            cmd.Parameters.Add(p2);

            SqlDataReader rd = cmd.ExecuteReader();

            if (rd.HasRows)
            {

                rd.Read();
                Session["id"] = TextBox1.Text;

                Label1.Text = "You are Authorized.";

                FormsAuthentication.RedirectFromLoginPage(TextBox1.Text, true);

                Response.Redirect("Welcome.aspx");

            }

            else
            {

                Label1.Text = "Invalid username or password.";
            }
        }

        catch
        {
        }

        finally
        {
        }
    }
}